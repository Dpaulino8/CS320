/**
 * 
 */
/**
 * 
 */
module Contact_class {
}